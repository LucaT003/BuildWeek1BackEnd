package models;

public enum TypeSeller {

	VENDING_MACHINE,
	AUTHORIZED_STORE
	
}
