package models;

//@Column(name = "subscription_duration")
//@Enumerated(EnumType.STRING)
//SubscriptionDuration subDuration;

public enum SubscriptionDuration {

	WEEKLY,
	MONTHLY
	
}
